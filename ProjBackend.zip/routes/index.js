module.exports = {
  AdminRoutes: require("./userRoutes"),
};
