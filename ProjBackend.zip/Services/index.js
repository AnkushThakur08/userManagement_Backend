module.exports = {
  userService: require("../Services/userService"),
};
