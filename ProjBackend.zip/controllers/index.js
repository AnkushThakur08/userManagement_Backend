module.exports = {
  userControllers: require("../controllers/userController"),
};
