module.exports = {
  UserModel: require("./userModel"),
  NotificationModel: require("./userNotification")
};
